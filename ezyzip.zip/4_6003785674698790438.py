from tkinter import Tk, Button, Label, Frame, Entry, messagebox, ttk, Canvas, Scrollbar, PhotoImage, Label, Toplevel, messagebox, ttk
# الاتصال بقاعدة البيانات
import pyodbc

DRIVER_NAME = 'SQL SERVER'
SERVER_NAME = 'AYA\SQLEXPRESS'
DATABASE_NAME = 'HospitalDataBase'
connection_string = f"""Driver={{{DRIVER_NAME}}};
                        Server={SERVER_NAME};
                        Database={DATABASE_NAME};
                        Trust_Connection=yes;"""

connection = pyodbc.connect(connection_string)
cursor = connection.cursor()

# Function to display records for a given table
def create_scrollable_frame(root):
    canvas = Canvas(root, bg="#e3f2fd")
    scrollbar = Scrollbar(root, orient="vertical", command=canvas.yview)
    scrollable_frame = Frame(canvas, bg="#e3f2fd")

    scrollable_frame.bind(
        "<Configure>",
        lambda e: canvas.configure(scrollregion=canvas.bbox("all"))
    )

    canvas.create_window((0, 0), window=scrollable_frame, anchor="nw")
    canvas.configure(yscrollcommand=scrollbar.set)

    canvas.pack(side="left", fill="both", expand=True)
    scrollbar.pack(side="right", fill="y")

    return scrollable_frame

# Function to display records for a given table

def view_records(table_name):
    for widget in frame.winfo_children():
        widget.destroy()  # Clear existing widgets

    Label(frame, text=f"{table_name} Records", font=("Arial", 24, "bold"), bg="#e3f2fd").pack(pady=20)

    # Fetch records
    cursor.execute(f"SELECT * FROM {table_name}")
    records = cursor.fetchall()

    # Display records in a Treeview
    columns = [column[0] for column in cursor.description]
    tree = ttk.Treeview(frame, columns=columns, show="headings")

    for col in columns:
        tree.heading(col, text=col)
        tree.column(col, width=120)

    tree.config(height=15)  # Adjust the number of rows displayed

    for record in records:
        tree.insert("", "end", values=record)

    tree.pack(fill="both", expand=True)

    # Add back button
    Button(frame, text="Back to Main Menu", command=main_menu, bg="#FF5733", fg="white", width=20, font=("Arial", 14)).pack(pady=10)
def view_patients(table_name):
    for widget in frame.winfo_children():
        widget.destroy()  # Clear existing widgets

    Label(frame, text=f"{table_name} Records", font=("Arial", 24, "bold"), bg="#e3f2fd").pack(pady=20)

    # Fetch records
    cursor.execute(f"SELECT * FROM {table_name}")
    records = cursor.fetchall()

    # Display records in a Treeview
    columns = [column[0] for column in cursor.description]
    tree = ttk.Treeview(frame, columns=columns, show="headings")

    for col in columns:
        tree.heading(col, text=col)
        tree.column(col, width=120)

    tree.config(height=15)  # Adjust the number of rows displayed

    for record in records:
        tree.insert("", "end", values=record)

    tree.pack(fill="both", expand=True)

    # Add back button
    Button(frame, text="Back to Main Menu", command=main_menu, bg="#FF5733", fg="white", width=20, font=("Arial", 14)).pack(pady=10)
    Button(frame, text="Patients above 40 or married", command=fetch_patients_above_40_or_married, bg="#FF5733", fg="white", width=25, font=("Arial", 14)).pack(pady=10)


def fetch_patients_above_40_or_married():
    # Execute specific query for patients with age > 40 or married
    cursor.execute("""
        SELECT 
    Patient_ID, 
    CONCAT(First_Name, '', Last_Name) AS Patient_Name, 
    Age, 
    Social_Status
FROM 
    Patient
WHERE 
    Age > 40 OR Social_Status = 'Married';
    """)
    patients_above_40_or_married = cursor.fetchall()

    # Clear existing widgets if any
    for widget in frame.winfo_children():
        widget.destroy()
    Label(frame, text="Patients with Age > 40 or Married", font=("Arial", 18, "bold"), bg="#e3f2fd").pack(pady=10)

    # Display results in a Treeview
    columns = ['Patient_ID', 'Patient_Name', 'Age', 'Social_Status']
    tree = ttk.Treeview(frame, columns=columns, show="headings")

    for col in columns:
        tree.heading(col, text=col)
        tree.column(col, width=120)

    tree.config(height=15)  # Adjust the number of rows displayed

    for patient in patients_above_40_or_married:
        tree.insert("", "end", values=patient)

    tree.pack(fill="both", expand=True)

    # Add back button
    Button(frame, text="Back to Main Menu", command=main_menu, bg="#FF5733", fg="white", width=20,
           font=("Arial", 14)).pack(pady=10)


# Function to add new records (Generic)
def add_record_new_window(table_name):
    new_window = Toplevel(root)
    new_window.geometry("600x400")
    new_window.title(f"Add New {table_name}")

    Label(new_window, text=f"Add New {table_name} Record", font=("Arial", 18, "bold"), bg="#e3f2fd").pack(pady=20)

    def save_new_record():
        try:
            values = [entry.get() for entry in entries]
            placeholders = ", ".join("?" * len(values))
            query = f"INSERT INTO {table_name} VALUES ({placeholders})"
            cursor.execute(query, values)
            connection.commit()

            messagebox.showinfo("Success", "Record added successfully!")

        except pyodbc.Error as e:
            messagebox.showerror("Database Error", str(e))

    # Get column names for the table
    cursor.execute(f"SELECT COLUMN_NAME FROM INFORMATION_SCHEMA.COLUMNS WHERE TABLE_NAME = '{table_name}'")
    columns = [column[0] for column in cursor.fetchall()]

    entries = []
    for col in columns:
        Label(new_window, text=col, font=("Arial", 14)).pack(pady=5)
        entry = Entry(new_window, width=30)
        entry.pack(pady=5)
        entries.append(entry)

    Button(new_window, text="Save", command=save_new_record, bg="#28A745", fg="white", width=20, font=("Arial", 14)).pack(pady=20)
    Button(new_window, text="Back to Main Menu", command=lambda: new_window.destroy(), bg="#FF5733", fg="white", width=20, font=("Arial", 14)).pack(pady=10)

def add_record(table_name):
    for widget in frame.winfo_children():
        widget.destroy()  # Clear existing widgets

    Label(frame, text=f"Add New {table_name} Record", font=("Arial", 24, "bold"), bg="#e3f2fd").pack(pady=10)

    def save_new_record():
        try:
            values = [entry.get() for entry in entries]
            placeholders = ", ".join("?" * len(values))
            query = f"INSERT INTO {table_name} VALUES ({placeholders})"
            cursor.execute(query, values)
            connection.commit()

            messagebox.showinfo("Success", "Record added successfully!")

        except pyodbc.Error as e:
            messagebox.showerror("Database Error", str(e))

    # Get column names for the table
    cursor.execute(f"SELECT COLUMN_NAME FROM INFORMATION_SCHEMA.COLUMNS WHERE TABLE_NAME = '{table_name}'")
    columns = [column[0] for column in cursor.fetchall()]

    entries = []
    for col in columns:
        Label(frame, text=col, font=("Arial", 14)).pack(pady=5)
        entry = Entry(frame, width=30)
        entry.pack(pady=5)
        entries.append(entry)

    Button(frame, text="Save", command=save_new_record, bg="#28A745", fg="white", width=20, font=("Arial", 14)).pack(pady=20)

    Button(frame, text="Back to Main Menu", command=main_menu, bg="#FF5733", fg="white", width=20, font=("Arial", 14)).pack(pady=10)

# Function to update existing records
def update_record(table_name):
    new_window = Toplevel(root)
    new_window.geometry("600x400")
    new_window.title(f"Update {table_name} Record")

    Label(new_window, text=f"Update {table_name} Record", font=("Arial", 18, "bold"), bg="#e3f2fd").pack(pady=20)

    def fetch_record():
        try:
            id_val = int(id_var.get())
            cursor.execute(f"SELECT * FROM {table_name} WHERE ID = ?", (id_val,))
            record = cursor.fetchone()

            if not record:
                messagebox.showerror("Error", "Record not found!")
                return

            # Pre-fill fields with fetched record
            for i, field in enumerate(record):
                entries[i].delete(0, 'end')
                entries[i].insert(0, str(field))

        except pyodbc.Error as e:
            messagebox.showerror("Database Error", str(e))

    def save_updated_record():
        try:
            id_val = int(id_var.get())
            values = [entry.get() for entry in entries]
            placeholders = ", ".join(f"{col} = ?" for col in columns)
            query = f"UPDATE {table_name} SET {placeholders} WHERE ID = ?"
            cursor.execute(query, (*values, id_val))
            connection.commit()

            messagebox.showinfo("Success", "Record updated successfully!")

        except pyodbc.Error as e:
            messagebox.showerror("Database Error", str(e))

    Label(new_window, text="Enter ID", font=("Arial", 14)).pack(pady=5)
    id_var = Entry(new_window, width=30)
    id_var.pack(pady=5)
    Button(new_window, text="Fetch Record", command=fetch_record, bg="green", fg="white", width=20).pack(pady=10)

    cursor.execute(f"SELECT COLUMN_NAME FROM INFORMATION_SCHEMA.COLUMNS WHERE TABLE_NAME = '{table_name}'")
    columns = [column[0] for column in cursor.fetchall()]

    entries = []
    for col in columns:
        Label(new_window, text=col, font=("Arial", 14)).pack(pady=5)
        entry = Entry(new_window, width=30)
        entry.pack(pady=5)
        entries.append(entry)

    Button(new_window, text="Save", command=save_updated_record, bg="#007BFF", fg="white", width=20, font=("Arial", 14)).pack(pady=20)
    Button(new_window, text="Back to Main Menu", command=lambda: new_window.destroy(), bg="#FF5733", fg="white", width=20, font=("Arial", 14)).pack(pady=10)

# Main menu function
def main_menu():
    for widget in frame.winfo_children():
        widget.destroy()  # Clear existing widgets

    Label(frame, text="Hospital Management System Menu", font=("Arial", 18, "bold"), bg="#e3f2fd").pack(pady=20)

    Button(frame, text="View Patients", command=lambda: view_patients("Patient"), bg="#4CAF50", fg="white", width=20, font=("Arial", 14)).pack(pady=10)
    Button(frame, text="View Doctors", command=lambda: view_records("Doctor"), bg="#4CAF50", fg="white", width=20, font=("Arial", 14)).pack(pady=10)
    Button(frame, text="View Nurses", command=lambda: view_records("Nurse"), bg="#4CAF50", fg="white", width=20, font=("Arial", 14)).pack(pady=10)
    Button(frame, text="View Departments", command=lambda: view_records("Department"), bg="#4CAF50", fg="white", width=20, font=("Arial", 14)).pack(pady=10)

    Button(frame, text="Add New Patient", command=lambda: add_record("Patient"), bg="#2196F3", fg="white", width=20, font=("Arial", 14)).pack(pady=10)
    Button(frame, text="Add New Doctor", command=lambda: add_record_new_window("Doctor"), bg="#2196F3", fg="white",
           width=20, font=("Arial", 14)).pack(pady=10)
    Button(frame, text="Add New Nurse", command=lambda: add_record_new_window("Nurse"), bg="#2196F3", fg="white", width=20, font=("Arial", 14)).pack(pady=10)
    Button(frame, text="Add New Department", command=lambda: add_record("Department"), bg="#2196F3", fg="white", width=20, font=("Arial", 14)).pack(pady=10)

    Button(frame, text="Update Patient Record", command=lambda: update_record("Patient"), bg="#FF9800", fg="white", width=20, font=("Arial", 14)).pack(pady=10)
    Button(frame, text="Update Doctor Record", command=lambda: update_record("Doctor"), bg="#FF9800", fg="white", width=20, font=("Arial", 14)).pack(pady=10)


# Main GUI

root = Tk()
root.geometry("1000x600")
root.title("Hospital Management System")
root.configure(bg="#e3f2fd")


Label(root, text="Hospital Management System", font=("Arial", 20, "bold"), bg="#e3f2fd").pack(pady=20)

frame = Frame(root, bg="#e3f2fd")
frame.pack(pady=20)


main_menu()  # Load the main menu initially


root.protocol("WM_DELETE_WINDOW", lambda: (connection.close(), root.destroy()))
root.mainloop()
